$( function() {
	
    //__________Counters
	$('.counter').countUp();

} );